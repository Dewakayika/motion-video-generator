# Genuine Solutions – 60s bumper animatic

- `index.html`: the original 60s animatic (HTML/CSS + GSAP 3.12.5 from cdnjs, Plus Jakarta Sans from Google Fonts). Open it in a browser to play/scrub.
- `index-60s.html`: 60s cut in the clean dark style, with product UI rebuilt from the Figma file (Find Candidates, Kanban, Resume sheet, job-seeker onboarding, dashboard, application detail).
- `index-30s.html`: 30s cut in the same style.
- `assets/figma/`: icons and images downloaded from Figma for those screens.
- `render.py`: renders any of them frame by frame to `frames/<name>/` (`python render.py index-60s.html`), then encode with ffmpeg (command in the file header).

## Where to edit
- Scene markup: the `scenes.innerHTML` template in the `<script>`.
- UI recreations: `dashLeads()`, `dashJob()`, `myApps()`, plus the phone screens in scene 9.
- Timing: everything lives in `build()`; each scene block is commented with its time range (e.g. `/* 6 Matching 28–36 */`). Times are absolute seconds.
- Colours: CSS tokens `--navy #09295C`, `--green #41FF95`, `--deep #061A3A`.
- VO captions: the `VO` array. Scene markers: the `SCN` array.

## Production swaps
- Replace the text-based `LOGO` constant with the official logo SVG.
- Replace the flat gradient star (`#bigstar`) with a rendered 3D star if needed.
- Requires internet for GSAP and the font; for offline rendering, download gsap.min.js locally and install Plus Jakarta Sans.
