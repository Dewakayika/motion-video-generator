"""Render an animatic to frames, then encode to MP4 with ffmpeg.
Usage:
  pip install playwright && playwright install chromium
  python render.py                  # index.html (60s)  -> frames/index/
  python render.py index-30s.html   # 30s cut           -> frames/index-30s/
  python render.py index-60s.html   # 60s, Figma UI     -> frames/index-60s/
  ffmpeg -framerate 30 -i frames/index-30s/%05d.jpg -c:v libx264 -crf 18 -pix_fmt yuv420p -movflags +faststart genuine-bumper-30s-16x9.mp4
"""
import asyncio, pathlib, sys
from playwright.async_api import async_playwright

FPS = 30
HERE = pathlib.Path(__file__).resolve().parent
SRC = HERE / (sys.argv[1] if len(sys.argv) > 1 else "index.html")
OUT = HERE / "frames" / SRC.stem

async def main():
    OUT.mkdir(parents=True, exist_ok=True)
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1920, "height": 1080})
        await page.goto(SRC.as_uri(), wait_until="load")
        # let fonts and images settle before driving the timeline; early calls can crash headless Chromium
        await page.wait_for_timeout(1500)
        await page.add_style_tag(content=(
            "body{padding:0!important;display:block!important}"
            "#viewport{width:1920px!important;border-radius:0!important;box-shadow:none!important}"
            "#controls{display:none!important}"))
        await page.evaluate("() => { fit(); TL.pause(); }")
        duration = round(await page.evaluate("() => TL.duration()"))
        for i in range(FPS * duration):
            t = i / FPS
            await page.evaluate(
                "t => { TL.seek(t); document.getAnimations().forEach(a => { a.pause(); a.currentTime = t * 1000; }); }", t)
            await page.screenshot(path=str(OUT / f"{i:05d}.jpg"), type="jpeg", quality=93)
            if i % 150 == 0:
                print(f"frame {i}/{FPS * duration}")
        await browser.close()

asyncio.run(main())
